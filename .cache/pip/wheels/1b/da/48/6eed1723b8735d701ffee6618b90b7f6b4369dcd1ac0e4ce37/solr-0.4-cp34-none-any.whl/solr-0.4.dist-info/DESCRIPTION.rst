solr
====

Client library for working with Solr. Includes async client version for Tornado.

